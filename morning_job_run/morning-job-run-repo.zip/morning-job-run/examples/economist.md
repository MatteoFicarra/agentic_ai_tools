# Example: economist moving to the private sector

A worked example of one setup, for an economist finishing a PhD and aiming for macro-economics roles in finance, based in western Europe. It's here to show what a filled-in configuration looks like. Your own setup will be built from your answers, not from this.

## Scoring dimensions

Appeal = (Role + Employer + Contract) × 100 / 75. Location caps the grade.

### Role (max 30): is economic analysis the core product of the team?

- 26–30: macro research, economist, strategist, sovereign or country-risk analyst, where economic analysis is what the team produces.
- 18–25: policy economist, research roles with narrower topics, strategist support roles.
- 10–17: adjacent: credit or ESG analysis, risk modelling, policy officer with some economics, statistics.
- 0–9: peripheral.

### Employer (max 25)

| Employer type | Points |
|---|---|
| Banks, investment banks, hedge funds, asset and wealth managers, private banks | 25 (a research institute inside a bank: 22) |
| Insurers, reinsurers and credit insurers | 22 |
| Rating agencies, macro research firms | 20 |
| Corporates with a market-facing economics or research unit | 20 |
| Top international organisations (IMF, World Bank, OECD, BIS, ECB) | 20 |
| EU institutions | 14 |
| Central banks, finance ministries, public banks | 13 |
| Think tanks, public research institutes, other international organisations | 12 |
| Other corporates, consultancies, tech companies (economics as an internal support function) | 6 |

This reflects a strong preference for finance over the public sector.

### Contract (max 20)

| Contract | Points |
|---|---|
| Permanent | 20 |
| Fixed-term with an extension or conversion path | 15 |
| Unknown | 12 |
| Fixed-term with no path | 5 |

## Location tiers

| Tier | Places | Highest grade |
|---|---|---|
| 1 | Two or three preferred cities | A |
| 2 | Other financial hubs in the region | B |
| 3 | Rest of Europe | C |
| 4 | Everywhere else | C |

Exception: global graduate-economist programmes count as tier 1 wherever they are.

## Hard exclusions

- Internships, traineeships, graduate/campus programmes, and country-specific equivalents (e.g. alternance and VIE in France)
- PhD positions and academic posts (professor, lecturer, postdoc)
- Roles requiring languages not spoken
- Very senior roles (Chief, Head of, Director, MD, 10+ years)
- Pure IT/data engineering, HR, legal, compliance, sales
- Unwanted sub-fields (e.g. health economics, competition consulting)

## Watchlist (sample)

The real list had about 150 employers in 8 categories. A sample of its shape:

- **Global banks and asset managers:** Goldman Sachs, J.P. Morgan, BlackRock, PIMCO, Allianz
- **Insurers and reinsurers:** Swiss Re, AXA, SCOR, Coface
- **Ratings and research firms:** S&P Global, Moody's, Fitch, Oxford Economics, Capital Economics
- **International organisations:** IMF, World Bank, OECD, BIS, ECB, EBRD
- **Job boards (leads only):** eFinancialCareers, EconJobMarket (non-academic), AEA JOE (non-academic), INOMICS, EURES

## LinkedIn alerts (example)

- `("economist" OR "macro strategist" OR "economic research") NOT (intern OR internship OR PhD)` · city 1 · Entry level + Associate + Mid-Senior · Full-time
- Same keywords · city 2
- `("sovereign analyst" OR "country risk" OR "macro analyst")` · region · Associate + Mid-Senior
