---
name: job-search-setup
description: "Sets up (or later changes) a personal daily job search in Claude: a guided interview on CV, target roles, preferences (contract, salary, remote work, seniority, location and more), watchlist and LinkedIn job alerts, then builds a personal 'Morning Job Run' dashboard and a personal daily-run skill, and helps schedule it every morning. Use whenever someone wants to set up an automated or daily job search, a job-hunting dashboard or a morning job run, or change their job-search scoring, watchlist, cities, alerts, profile or settings, even if they don't name this skill."
---

# Job search setup

This kit sets up a daily job search for one person (called **the user** below). At the end of setup they have:

1. **A dashboard:** a page in their Claude account titled "Morning Job Run – <Name>", where new openings appear every morning, graded A–D, with tabs To review / To be checked / Shortlist / Apply / Dismissed / All / Archive. They mark jobs Apply / Maybe / ✕ and leave notes; the next run learns from them.
2. **A personal skill `morning-job-run-<name>`:** it runs the daily search into that dashboard, and checks "to be checked" postings in Chrome when asked.
3. **LinkedIn job alerts** designed from their profile, feeding the daily run.
4. **A scheduled morning run.**

This kit does not run the job search itself. It builds the skill that does, and later updates it ("update mode", below).

Files in this kit:

- `references/preferences.md`: the preference questions (contract, salary, work mode, seniority…) and how each answer becomes scoring.
- `references/linkedin_alerts.md`: designing the alerts and walking the user through creating them.
- `references/defaults.md`: neutral starting points to show during the interview.
- `references/personal_skill_template.md`: the daily-run skill, with `{{PLACEHOLDERS}}` to fill.
- `references/optional_modules.md`: tracker and cover-letter sections, spliced in only if wanted.
- `references/placeholders.md`: every placeholder, where its value comes from, and a final check.
- `assets/dashboard_template.html`: the dashboard page.

---

## Ground rules

- **Their answers, not the defaults.** `defaults.md` and any examples are starting points. Never assume they apply.
- **One topic at a time.** Keep each turn short. Use the tappable-options tool for choices and plain questions for open answers. Summarise what you understood before moving on. Draft whatever you can yourself (from the CV, from web search) and ask them to correct it, rather than asking open questions they have to think hard about.
- **Their language.** Run the interview in the language the user writes in. Write the skill in English unless they ask otherwise (it's read by Claude), but keep job titles and keywords in the languages their target postings use.
- **Personal data stays in their skill.** Don't put their details anywhere else (no memory notes, no other artifacts).
- **No actions on their behalf.** Claude designs LinkedIn alerts and schedules, but the user creates them. Claude never signs in, applies, or contacts anyone.
- A skill can't save changes to itself from a chat. The output is always a new skill file they install with **Save skill**.

---

## Setup mode (first time)

### 0. Welcome, checklist and tools

Tell them what will happen: about 20–40 minutes of questions, then Claude builds the dashboard and the skill, and they do three things themselves (set up LinkedIn alerts, click Save skill, set up the morning schedule). They can stop and continue later; if they do, give them a short summary of their answers so far to paste into the next chat.

Show this checklist, then check what the session actually has, and say plainly what's missing and how to turn it on:

**Needed**
- [ ] **Their CV** (PDF or Word) to upload.
- [ ] **Code execution and file creation** switched on (Settings), needed to build skills.
- [ ] **The Artifact tool with the database capability**, needed for the dashboard. Check with the Artifact tool's `capabilities` action that `db` and `user` are available. If not, stop: the kit can't build the dashboard on this account or plan.
- [ ] **Skills** enabled on their plan, so they can install the generated skill.

**Strongly recommended**
- [ ] **An email connector** (Gmail) for the mailbox that will receive job alerts.
- [ ] **A LinkedIn account** that can receive job alerts by email (set up in step 10).
- [ ] **Scheduled tasks** on their plan and app, for the unattended morning run. Without it, they start each run by saying "run my job search".

**Optional**
- [ ] **Claude in Chrome**, for the verification pass (checking postings on employer sites and LinkedIn while they watch). Can be added later.
- [ ] **A connected folder** (Claude desktop app / Cowork), only for the tracker and cover-letter modules.
- [ ] **A list of contacts** at employers they're interested in.
- [ ] **Their application tracker** (spreadsheet) and **1–3 recent cover letters**, only for those modules.

Then ask:

- **Their first name** (used in titles and file names) and full name (for the profile). Make the slug: lowercase first name, letters and digits only, hyphens instead of spaces (e.g. "Anna-Lena" → `anna-lena`). The skill name must be `morning-job-run-<slug>` and contain no underscores.
- **"Does anyone else use this Claude account?"** If yes, switch on **shared-account mode**:
  - confirm you're talking with the person the search is for;
  - everything created carries their name (already the case for titles and files);
  - never read, change or reuse other people's skills, artifacts, files or mail;
  - the email connector belongs to the account, not the person: confirm whose mailbox it is before using it (step 1).

### 1. Email

- If an email connector is connected, run one small search (e.g. the most recent email from LinkedIn) and ask them to confirm the mailbox address shown is theirs. In shared-account mode, if it's someone else's mailbox, stop using it: explain that the connector reads whichever mailbox was connected to the account, and let them choose between reconnecting their own (after agreeing it with the other person) or running without email.
- If no email connector is connected, explain the trade-off: without email the run can't read job alerts, so it finds fewer jobs and later. Offer to turn it on (look for the connector) or continue without.
- Record → `{{EMAIL_ADDRESS}}`, or "none".

### 2. Profile

Ask them to upload their CV. Draft the profile from it (education, current role, previous roles, main work or projects, skills, languages with levels, tools, qualifications or licences) and show it back briefly. Then ask only for gaps:

- current situation and availability (start date, notice period, contract end);
- years of experience in their field, as they'd count them;
- languages that rule a job out, and tools or skills they're weak in;
- what has got them interviews so far, and what never has;
- eligibility (work permits, nationality rules, required licences);
- people they'd name as references (only if they want cover letters).

Result → `{{PROFILE}}`: short bullet sections (Education, Current role, Previous roles, Main work, Skills, Languages, Other, References if any).

### 3. Field and target roles

- `{{SEARCH_LABEL}}`: a 2–4 word label for the dashboard (e.g. "data analyst job search").
- `{{ROLE_QUESTION}}`: "Is <their core skill> the core product of the team?"
- `{{ROLE_BANDS}}` and `{{ROLE_MAX}}` (default 30): four bands with concrete job titles for their field (structure in `defaults.md`). Draft them from the CV and their answer to "which jobs are you aiming for?", then let them correct.

### 4. Preferences

Follow `references/preferences.md`: one multi-select on what matters to them, then one follow-up per ticked item, then propose weights. This fills `{{SCORING_DIMENSIONS}}`, `{{DIMENSION_KEYS}}`, `{{MAX_TOTAL}}`, `{{CAP_RULES}}`, and contributes to exclusions and fit.

Write each points dimension in `{{SCORING_DIMENSIONS}}` as:

```
### <Label> (max <N>) — key `<key>`

| <What> | Points |
|---|---|
| … | … |
```

Use the key names from `preferences.md` (`employer`, `contract`, `salary`, `work_mode`, `seniority`, `hours`, `size`, `travel`), or a short snake_case key for their own criterion.

### 5. Location

Ask where they want to work and whether they'd relocate (see "Location and relocation" in `preferences.md`) → `{{LOCATION_ROWS}}` (table rows: tier | places | highest grade) and `{{LOCATION_NOTES}}` (order within tier 1 for tie-breaks, remote rule, exceptions).

### 6. Fit, exclusions, grading, wants

1. **Fit** → `{{FIT_CRITERIA}}`: themes that match their record, experience range, languages, tools, qualifications, eligibility, history (from steps 2 and 4).
2. **Hard exclusions** → `{{HARD_EXCLUSIONS}}`: the must-haves from step 4, plus the common list in `defaults.md`, item by item.
3. **Grading:** keep the default thresholds unless they ask (`{{A_MIN}}` 80, `{{B_MIN}}` 65, `{{C_MIN}}` 50, `{{A_MIN_MINUS_1}}` 79, `{{B_MIN_MINUS_1}}` 64) and `{{GRADE_LABELS}}` (e.g. "A = dream, B = strong fit, C = safety, D = long shot", or their tracker's labels).
4. **What they want** → `{{WANTS}}`: 3–5 lines in their words on direction, location, contract, pay, work mode and hard no's.

Set `{{RUBRIC_VERSION}}` to 1.

### 7. Watchlist

Propose employers grouped into 4–8 categories (by city and/or sector) that fit their field, cities and employer preferences. Use web search to check each has a careers page and, ideally, a team doing their kind of work; aim for 30–80 employers in total. Show the list, let them remove and add, then fill `{{WATCHLIST}}` (one bullet per category: `- **<Category>:** Employer, Employer, …`) and `{{WATCHLIST_CATEGORY_NAMES}}` (category names separated by " / "). End with a "Job boards (leads only)" bullet: the general and field-specific boards for their country (see `defaults.md`).

### 8. Contacts (optional)

People at watchlist employers who could refer them or tell them about openings: name, organisation, role, and whether they'd refer them. They can paste a list or skip → `{{CONTACTS}}` ("None yet." if skipped).

### 9. Optional modules

Ask whether they want the **tracker** and/or **cover-letter** modules (both need a connected folder). If yes, follow `references/optional_modules.md`. If no, fill those placeholders as that file explains. Set `{{DRAFTS_FOLDER}}` to `Claude drafts – <Name>`.

### 10. LinkedIn job alerts

Follow `references/linkedin_alerts.md`: design 3–8 alerts from everything gathered so far, show the plan, then walk them through creating each one and checking the email settings. Fill `{{LINKEDIN_ALERTS}}` (one line per alert: name · keywords · location · filters) and `{{ALERT_SENDERS}}` (default `jobalerts-noreply@linkedin.com OR jobs-noreply@linkedin.com`, plus any other boards' alert senders). Set `{{EMAIL_MODE_NOTE}}` to "skip this step if there is no email connector in the session" (or, if they chose no email in step 1, to "email is not used: skip this step").

If they'd rather do the alerts later, record the plan in `{{LINKEDIN_ALERTS}}` anyway, marked "not yet created", and remind them at the end.

### 11. Schedule

Ask what time and time zone the morning run should happen → `{{RUN_TIME}}` (e.g. "07:30 Zurich time").

### 12. Confirm

Show a compact summary: profile headline, role bands, scoring dimensions with maxima, caps, location tiers, exclusions, watchlist size by category, alerts, modules, run time. Build only after they say it's right.

### 13. Build the dashboard

1. Check the Artifact tool's `capabilities` again (`db` and `user`).
2. Copy `assets/dashboard_template.html` to `/mnt/user-data/outputs/morning-job-run-<slug>.html`, replacing `{{OWNER_NAME}}`, `{{OWNER_SLUG}}` and `{{SEARCH_LABEL}}`. Check no `{{` remains.
3. Publish it: action `publish`, that file, title "Morning Job Run – <Name>", favicon 🗂️, capabilities `{"db": {}, "user": {}}`. Record the returned link as `{{DASHBOARD_URL}}`.
4. Write the display settings with `write_db` `set` on collection `config`, doc id `display`:
   ```
   {"owner": "<Name>",
    "dimensions": [{"key": "role", "label": "Role", "max": 30}, …one per points dimension, in rubric order],
    "tier_caps": {"1": "A", "2": "B", "3": "C", "4": "C"},
    "legend": [3–5 short lines explaining their scoring: appeal and its dimensions, location cap with their tier-1 places named, other caps, fit, grade thresholds],
    "footer": "Updated each morning by Claude. Mark jobs Apply, Maybe or ✕ and leave notes: the next run learns from them."}
   ```
   If the cover-letter module is on, end the footer with "Ask Claude in chat for cover letters for jobs marked Apply."

### 14. Build the personal skill

1. Copy `references/personal_skill_template.md` to `/tmp/morning-job-run-<slug>/SKILL.md` and fill every placeholder, using `references/placeholders.md` as the checklist.
2. Check: `grep -n "{{" SKILL.md` returns nothing; the `name` is exactly `morning-job-run-<slug>`; the description is under about 1,000 characters.
3. If `/mnt/skills/examples/skill-creator/scripts/package_skill.py` exists, run it from that folder (`python -m scripts.package_skill /tmp/morning-job-run-<slug> /tmp/pkg`) and present the `.skill` file with `present_files`. Otherwise zip the folder (`morning-job-run-<slug>/SKILL.md` inside) and present that.
4. Tell them to click **Save skill** on the card. If there's no button, they can upload the file where skills are managed in Settings. Ask them to check afterwards that the installed skill is called `morning-job-run-<slug>`.
5. Remind them the skill file contains their CV details: keep it private and don't share it or commit it to a public repository.

### 15. Schedule the morning run

Look up the current steps for scheduled tasks on support.claude.com (they change), then walk them through creating one:

- name: "Morning Job Run – <Name>";
- time: their `{{RUN_TIME}}`;
- prompt: "Run <Name>'s morning job run (skill morning-job-run-<slug>). This is the unattended scheduled run."

If scheduled tasks aren't available on their plan or app, tell them they can start each run by opening a chat and saying "run my job search".

### 16. First run

Suggest they open a **new chat** and say "run my job search", to watch the first run and confirm the skill loads (it should mention their dashboard by name). The first run can be thin if the LinkedIn alerts haven't sent anything yet; that's normal. Then, with Chrome connected, "check the dashboard" to try the verification pass. Remind them how to use the dashboard: Apply / Maybe / ✕ and notes, which the next run reads.

---

## Update mode (any time later)

When they want to change something (add employers, change cities, reweight or add a criterion, new exclusions, a new CV, different alerts):

1. Find their installed skill: look for `morning-job-run-*/SKILL.md` under `/mnt/skills/` (e.g. `find /mnt/skills -path "*morning-job-run-*" -name SKILL.md`). If several exist, ask which is theirs; in shared-account mode, never open the others. If none is there, ask them to upload their skill file.
2. Copy it to `/tmp/morning-job-run-<slug>/SKILL.md` and make only the changes asked for. Show a short before/after.
3. If the scoring changed (role bands, any dimension or its maximum, caps, tiers, grade thresholds), increase the rubric version number everywhere it appears, so the next run rescores existing jobs once, and update `{{MAX_TOTAL}}`'s value if maxima changed. Update the `config/display` doc (`write_db` `update`) if dimensions, legend, caps or footer changed.
4. If roles, places or filters changed, propose the matching LinkedIn alert changes (`linkedin_alerts.md`, "Later changes") and update the "LinkedIn alerts" section.
5. Package and present as in step 14; they click Save skill and confirm replacing the old version.

Never republish the dashboard page just to change settings; the page reads its dimensions, legend and footer from `config/display`. Republish only if the page itself needs changing, using the dashboard's link as `url` so it updates in place.
