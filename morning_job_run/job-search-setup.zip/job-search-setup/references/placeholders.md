# Placeholder map

Every placeholder in `personal_skill_template.md`, where its value comes from, and what to use when it doesn't apply. After filling, `grep -n "{{" SKILL.md` must return nothing.

| Placeholder | Source (setup step) | If not applicable |
|---|---|---|
| `{{OWNER_NAME}}` | First name (0) | — |
| `{{OWNER_SLUG}}` | Slug of the first name (0) | — |
| `{{OWNER_FULL_NAME}}` | Full name (0) | — |
| `{{SHARED_DESC}}` | Shared-account mode (0): ` (belongs to <Name> only)` | empty string |
| `{{SHARED_ACCOUNT_RULE}}` | Shared-account mode (0), the lines below | empty string |
| `{{EMAIL_ADDRESS}}` | Confirmed mailbox (1) | `none (email not used)` |
| `{{EMAIL_MODE_NOTE}}` | Step 10 | — |
| `{{ALERT_SENDERS}}` | Step 10 | LinkedIn default |
| `{{PROFILE}}` | Step 2 | — |
| `{{SEARCH_LABEL}}` | Step 3 | — |
| `{{ROLE_QUESTION}}`, `{{ROLE_BANDS}}`, `{{ROLE_MAX}}` | Step 3 | `{{ROLE_MAX}}` 30 |
| `{{SCORING_DIMENSIONS}}` | Step 4 | empty string if role is the only dimension |
| `{{DIMENSION_KEYS}}` | Step 4: the keys, role first, e.g. `role, contract, salary, work_mode` | `role` |
| `{{MAX_TOTAL}}` | Sum of all maxima, role included | — |
| `{{CAP_RULES}}` | Step 4 caps other than location | `None.` |
| `{{LOCATION_ROWS}}`, `{{LOCATION_NOTES}}` | Step 5 | — |
| `{{FIT_CRITERIA}}` | Step 6 | — |
| `{{HARD_EXCLUSIONS}}` | Step 6 | — |
| `{{A_MIN}}`, `{{B_MIN}}`, `{{C_MIN}}`, `{{A_MIN_MINUS_1}}`, `{{B_MIN_MINUS_1}}` | Step 6 (80, 65, 50, 79, 64) | — |
| `{{GRADE_LABELS}}` | Step 6 | — |
| `{{WANTS}}` | Step 6 | — |
| `{{RUBRIC_VERSION}}` | 1 at setup; +1 on each scoring change | — |
| `{{WATCHLIST}}`, `{{WATCHLIST_CATEGORY_NAMES}}` | Step 7 | — |
| `{{CONTACTS}}` | Step 8 | `None yet.` |
| `{{DRAFTS_FOLDER}}` | `Claude drafts – <Name>` | — |
| `{{OPTIONAL_DESC}}`, `{{OPTIONAL_TRIGGERS}}`, `{{OPTIONAL_JOBS_LIST}}`, `{{TRACKER_RULE}}`, `{{TRACKER_XREF}}`, `{{TRACKER_SECTION}}`, `{{COVER_LETTER_SECTION}}`, `{{SCHEDULED_EXTRA}}` | Step 9, per `optional_modules.md` | empty strings |
| `{{LINKEDIN_ALERTS}}` | Step 10 | `None (email alerts not used).` |
| `{{RUN_TIME}}` | Step 11 | — |
| `{{DASHBOARD_URL}}` | Step 13 | — |

## `{{SHARED_ACCOUNT_RULE}}` text (shared-account mode only)

Indented as sub-bullets of rule 1:

```
   - This Claude account is shared. Never read, change or run other people's skills, artifacts, files or mail.
   - The email connector belongs to the account, not to {{OWNER_NAME}}: only read the mailbox in rule 4, and stop if a different one is connected.
```

(Replace `{{OWNER_NAME}}` inside it too.)

## Final checks before packaging

- No `{{` left anywhere.
- `name` is `morning-job-run-<slug>`, lowercase, hyphens only.
- Every key in `{{DIMENSION_KEYS}}` has a subsection in the rubric (role in its own section, the others in `{{SCORING_DIMENSIONS}}`), and the same keys and maxima are in `config/display` → `dimensions`.
- `{{MAX_TOTAL}}` equals the sum of the maxima.
- Tier caps in `{{LOCATION_ROWS}}` match `tier_caps` in `config/display`.
