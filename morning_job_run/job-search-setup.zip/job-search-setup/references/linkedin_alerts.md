# Setting up LinkedIn job alerts

LinkedIn job alerts are usually the best daily source: LinkedIn emails new matching postings, and the daily run reads those emails. Do this step **after** the profile, preferences and watchlist are done, because the alerts are built from them.

The user creates the alerts themselves, in their own LinkedIn account. Claude designs them and walks them through it; Claude never signs in to LinkedIn or creates alerts for them.

---

## 1. Design the alerts

Propose **3–8 alerts**. Fewer, well-aimed alerts beat many broad ones: each alert email is capped at a handful of jobs, and broad searches bury the good ones.

Build them from the interview:

- **One alert per main role family × location area.** E.g. "data analyst" roles in tier-1 cities; the same roles as remote; a second role family in tier-1 cities.
- **Keywords:** LinkedIn's job search accepts Boolean operators in the keyword box: `AND`, `OR`, `NOT` (in capitals), quotes for exact phrases, and parentheses. Use them to cover title variants and drop noise, e.g.
  `("data analyst" OR "business analyst" OR "analytics engineer") NOT (intern OR internship OR senior)`.
  Use the job titles from their top two role bands, in every language their target postings use (e.g. English and German titles for Zurich).
- **Location:** one city or region per alert, with the distance radius if offered. For remote, set the location to their country (or the region they can legally work in) and the remote filter.
- **Filters**, taken from their preferences:
  - Experience level (Internship, Entry level, Associate, Mid-Senior level, Director, Executive): tick the levels they target; untick the ones in their exclusions.
  - Job type (Full-time, Part-time, Contract, Temporary, etc.): match their contract and hours answers.
  - On-site / Hybrid / Remote: match their work-mode answer. If one mode is only a cap, keep it ticked (the scoring handles it); untick only modes they excluded.
  - Leave "Date posted" on "Any time" (the alert only sends new jobs anyway).
  - Company or industry filters only if they're sure; they hide unexpected good employers.
- **Delivery:** daily, by email, to the address the daily run reads.

Show the plan as a short table: alert name · keywords · location · filters. Let them adjust before they start.

---

## 2. Walk them through creating each one

LinkedIn's interface changes often, so describe the steps in general terms and let them tell you what they see. If they're stuck, look up LinkedIn's current help page for job alerts with web search.

For each alert:

1. On linkedin.com, open **Jobs** and type the keywords and location from the plan into the search boxes; run the search.
2. Open the filters (often **All filters**) and set experience level, job type and on-site/remote as planned. Apply.
3. Glance at the first results with them: if most are clearly wrong, adjust the keywords (add a `NOT` term or a title variant) before saving.
4. Switch on the job alert for this search (a **Set alert** toggle or button near the results).
5. In the alert settings (on the page or under **Job alerts / Manage alerts**): frequency **daily**, notifications **by email** (and in-app if they like).

After all alerts are set:

- Check that LinkedIn sends email to the address the daily run reads (LinkedIn **Settings → Account preferences / Communications → Email**; the primary email must be that address, and job-alert emails must be on).
- Tell them the first alert emails can take a day or two to arrive, and that they can delete alert emails after reading: the run also looks in the bin.
- Record the alert plan (names, keywords, locations, filters) in their skill under "LinkedIn alerts", so they can rebuild or change them later.

---

## 3. Other alert sources (optional)

If they use other boards that send email alerts (e.g. Indeed, Glassdoor, national or sector boards), they can set those up the same way. Add each sender to `{{ALERT_SENDERS}}` so the daily run reads them too. Treat them as leads: aggregator postings still need confirming (see the daily-run skill).

## 4. If they don't want email alerts

The daily run still works from career sites and job boards (the watchlist), but it will find fewer jobs, later. Say so plainly, and set `{{EMAIL_MODE}}` to "none".

## Later changes

In update mode, when their roles, cities or filters change, propose the matching alert changes (which alerts to edit, add or delete) and update the "LinkedIn alerts" section of their skill.
