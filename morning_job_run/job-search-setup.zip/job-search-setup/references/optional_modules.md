# Optional modules

Splice these into the personal skill template only if the user switched them on during setup. Both need a connected job-search folder (Claude desktop app / Cowork with folder access); in a plain web chat they can't run, so say so if they want them there.

Number the lines in `{{OPTIONAL_JOBS_LIST}}` to follow on from the two fixed items (3, then 4). If a module is off, replace its placeholders with an empty string (and `{{TRACKER_XREF}}` with "", `{{OPTIONAL_DESC}}` / `{{OPTIONAL_TRIGGERS}}` / `{{OPTIONAL_JOBS_LIST}}` with only the parts for modules that are on).

---

## Tracker module

**`{{OPTIONAL_JOBS_LIST}}` line:** `3. **Tracker:** add the jobs {{OWNER_NAME}} picks to the application tracker.`
**`{{OPTIONAL_DESC}}` part:** `, update the application tracker`
**`{{OPTIONAL_TRIGGERS}}` part:** `, 'tracker'`
**`{{TRACKER_XREF}}`:** `, and \`in_tracker\` from the tracker (if the folder is available)`
**`{{SCHEDULED_EXTRA}}` part:** `, no tracker edits`

**`{{TRACKER_RULE}}`:**

```
6. **Tracker:** only touch it when {{OWNER_NAME}} asks for a specific job to be added. Only append new rows; never change existing rows. Save a backup copy (`<tracker name>_backup_YYYY-MM-DD.xlsx` in `{{DRAFTS_FOLDER}}/backups/`) before every edit.
```

**`{{TRACKER_SECTION}}`** (fill from the tracker shown during setup; if there is none, the setup skill creates a simple one and describes it here):

```
---

## Tracker (needs the connected job-search folder)

File: `<file name>`, sheet `<sheet name>`. Header row <n>; data from row <n>.

Columns: <list them in order>.

Dropdown values: <for each column with data validation, its allowed values>.

**Adding a job:**

1. Back up first.
2. Append at the next empty row (with the next ID, if there is an ID column).
3. Map the grade to the priority column if there is one (<their mapping, e.g. A → "High">); set the "not started" status value.
4. Put the deadline as a date. Copy the formula pattern of the row above for any formula columns.
5. Notes in the same style: <describe, from the existing rows>.
6. Keep formatting and data validation (openpyxl, load without `data_only`).
7. Update the dashboard doc's `in_tracker` field afterwards.
```

---

## Cover-letter module

**`{{OPTIONAL_JOBS_LIST}}` line:** `4. **Cover letters:** write letters for the jobs {{OWNER_NAME}} marks "Apply".`
**`{{OPTIONAL_DESC}}` part:** `, and write cover letters`
**`{{OPTIONAL_TRIGGERS}}` part:** `, 'cover letter'`
**`{{SCHEDULED_EXTRA}}` part:** `, no cover letters`

**`{{COVER_LETTER_SECTION}}`** (fill from 1–3 of the user's own recent letters and CV; describe the format, never copy a letter's text):

```
---

## Cover letters (needs the connected folder)

**Where they go:** `{{DRAFTS_FOLDER}}/<Employer>_<Short position>/`. Save `Cover letter – {{OWNER_NAME}} – <Employer>.docx` (use the docx skill) and a PDF export.

**Before writing, read:** the posting (dashboard `remit`/`profile`/`url`), the latest letters in the folder (best model: <file>), the CV, and any `my_note` on the job.

**Format, as in the existing letters:** header block <…>; recipient <…>; date style <…>; subject line <…>; salutation <…>; close <…>; length <…>; language rule <e.g. write in the posting's language, or ask first>.

**Structure:** <paragraph-by-paragraph outline taken from the existing letters>.

**Style:** first person, <their tone>; concrete numbers from their record; match the posting's words for the skills it asks for; never claim skills they lack (<list what they said they don't have>); no invented facts.

**After writing:** tell {{OWNER_NAME}} in 2–3 lines what you emphasised and anything to check.
```
