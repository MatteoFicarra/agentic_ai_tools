# Preferences: questions and how answers become scoring

Every job gets two numbers and a grade:

- **Appeal (0–100):** how much the user would *want* this job. It is the sum of the points from their chosen criteria, rescaled to 100.
- **Fit (0–100):** how likely they are to *get* it, given their record.
- **Grade (A–D):** from appeal and fit, then lowered by any caps.

Each preference the user cares about is turned into one of four things. The answer to "how much does this matter?" decides which:

| How much it matters | Becomes | Example |
|---|---|---|
| Must-have / deal-breaker | **Hard exclusion**: the job is never added | "Nothing below 60k", "no fully on-site roles" |
| Strong preference | **Points dimension** that adds to appeal, with a maximum the user sets | Remote 15, hybrid 10, on-site 0 |
| Limits how good a job can be | **Grade cap** | "On-site can be at most a C for me" |
| Doesn't matter | Nothing; skip it | |

One preference can be both an exclusion and points: e.g. "below 50k is out (exclusion); 50–70k gets 5 points, 70k+ gets 15".

---

## How to ask

1. **Always asked (core):** field and target roles (role dimension, always on), and where they want to work (location, see below).
2. **One multi-select** with the tappable-options tool: "Which of these also matter to you when you look at a job?" Offer the menu below (the tool takes up to 4 options per question, so split it into two or three questions of related items, or ask in plain text with a short list). Add "Something else" so they can name their own criterion.
3. **For each ticked item, one short follow-up**: what they prefer, and how much it matters (the four levels above). Use options where the answers are a fixed set.
4. **Propose the weights yourself**, then let them adjust. Rule of thumb: role 30, then their most important criteria 15–25, minor ones 5–10. Keep 3–5 points dimensions in total (role included); more makes the score noisy. Everything else becomes an exclusion, a cap or nothing.
5. Summarise as a small table: criterion → exclusion / points (with the scale) / cap / ignored.

---

## The menu

For each: what to ask, the dashboard key, and a typical points scale (as a share of its maximum, so it works with any weight).

### Role (always on) — key `role`
Covered in the main interview: "Is <their core skill> the core product of the team?" Four bands: top (90–100% of max), solid (60–85%), adjacent (33–57%), peripheral (0–30%), written for their field with concrete role names.

### Employer type — key `employer`
"Where would you most like to end up?" (e.g. large companies, start-ups, public sector, NGOs and international organisations, consultancies, universities, hospitals, specific industries). Rank 5–10 employer types; top type gets the maximum.

### Contract — key `contract`
"Permanent, temporary or freelance: what works for you?" Typical scale: preferred type 100%; acceptable with a path to the preferred type 75%; unknown 60%; acceptable without a path 25%. For people who *prefer* temporary or freelance work, reverse it. A type they would never take becomes an exclusion.

### Salary — key `salary`
Ask: currency, gross or net, yearly or hourly; the minimum they would accept; the level that would make them happy. Typical: minimum → exclusion *only when the posting states a salary below it*; scale between minimum and target (0% at the minimum, 100% at or above target). **Many postings don't state a salary**: give "not stated" the middle of the scale (50%) and never exclude a job for not stating it.

### Work mode — key `work_mode`
"On-site, hybrid or remote?" Typical: preferred mode 100%, next 50–70%, least 0%; or an exclusion ("no fully on-site") or a cap ("on-site at most B"). **Remote changes location**: a fully remote job counts as location tier 1 if they can work from where they live; check the posting's country or time-zone restrictions.

### Seniority and experience — key `seniority`
"What level are you aiming for?" (entry / junior / mid / senior / lead / manager), and how many years of experience they have. Usually better as an **exclusion** (too junior, too senior) plus part of **fit** (years asked vs years they have) than as points. Use points only if they have a clear preferred level among several acceptable ones.

### Hours — key `hours`
Full-time / part-time / either. Usually an exclusion; points if they prefer one but would take the other.

### Location and relocation — tiers, not points
"Which cities or regions? Would you relocate, and where to?" Build tiers: tier 1 (top places, up to A), tier 2 (acceptable, up to B), tier 3 (rest of the region, up to C), tier 4 (everywhere else, up to C or "never add"). Ask their order within tier 1 (for tie-breaks only) and any exceptions (e.g. a programme they'd move anywhere for). If location barely matters to them, use a single tier with no cap.

### Employer size — key `size`
Start-up / small / medium / large / very large. Points or a cap.

### Languages — fit and exclusions
Which working languages are fine, which rule a job out. Goes into fit criteria and exclusions, not points.

### Visa and work permits — exclusions and fit
Where they can work without sponsorship; whether they need sponsorship elsewhere. A job requiring a permit they can't get is excluded; "sponsorship available" can be noted in `why`.

### Start date — fit and notes
Earliest start date, notice period. Mostly a note; an exclusion only for clearly incompatible start dates.

### Travel — key `travel`
How much travel is OK. Exclusion above a limit, or points.

### Something else
Mission or sector they care about, specific technologies, team size, schedule (shifts, nights), benefits. Fit it into one of the four shapes; if it doesn't fit, it goes into "what they want" for judgement.

---

## Where each answer goes

- **Points dimensions** → `{{SCORING_DIMENSIONS}}` (one subsection per dimension with its maximum and its scale table) and the `dimensions` list in `config/display` (`[{key, label, max}]`, role first).
- **Total of the maxima** → `{{MAX_TOTAL}}` (appeal = total points × 100 / `{{MAX_TOTAL}}`).
- **Caps** → `{{CAP_RULES}}` (location tiers are written separately in `{{LOCATION_ROWS}}`), and `tier_caps` in `config/display`.
- **Exclusions** → `{{HARD_EXCLUSIONS}}`.
- **Fit-related answers** (experience, languages, permits, tools) → `{{FIT_CRITERIA}}`.
- **Everything, in their words** → `{{WANTS}}`.
