# Starting defaults

Neutral starting points to show during the interview ("here's a common setup; what should change for you?"). They are examples, never the user's answers. For a fully worked example in one field, see `examples/` in the repository (if the user has it).

## Scoring mechanics (keep unless they ask)

- **Appeal** = (sum of points over their chosen dimensions) × 100 / (sum of the maxima), rounded.
- **Role** is always a dimension (default maximum 30). Other dimensions come from `preferences.md` (typically 3–5 in total, role included).
- **Location** doesn't add points; its tier caps the grade. Other caps are allowed (see `preferences.md`).
- **Grade:** D if fit < 50; otherwise A if appeal ≥ 80, B if 65–79, C if 50–64 and fit ≥ 70, D otherwise; then apply caps (never raise a grade).
- **Tier caps:** tier 1 → A, tier 2 → B, tiers 3 and 4 → C.
- **Grade meanings:** A = dream, B = strong fit, C = safety, D = long shot. They can rename these.

If they want different maxima, thresholds or caps, change them consistently in their skill, in the `config/display` document, and bump the rubric version.

## Role bands (structure)

The question the bands answer: "Is <their core skill> the core product of the team?" With a maximum of 30:

- 26–30: the role *is* their core work, at the level they want.
- 18–25: their core work, but narrower, more junior/senior than ideal, or a support version of it.
- 10–17: adjacent roles where their skills are useful but not central.
- 0–9: peripheral.

Write each band for their field with 3–6 concrete job titles. Draft it from their CV and target roles, then let them correct it.

## Employer types (structure)

5–10 rows, top type = the dimension's maximum. Draft from their answer to "where would you most like to end up?". Common types to choose from: large companies in a named industry; start-ups and scale-ups; small and medium companies; consultancies; public administration; international organisations; NGOs and non-profits; universities and research institutes; hospitals and health providers; schools; agencies and recruiters (usually lowest, or excluded). Add sector-specific rows (e.g. "banks and insurers", "pharma", "game studios") when they have them.

## Contract (example scale, maximum 20)

| Contract | Points |
|---|---|
| Their preferred type (e.g. permanent) | 20 |
| Acceptable type with a path to the preferred one | 15 |
| Unknown | 12 |
| Acceptable type with no path | 5 |

Reverse or adapt it for people who prefer temporary, freelance or contract work.

## Location tiers (structure)

| Tier | Places | Highest grade |
|---|---|---|
| 1 | Their top cities (and remote, if they can work remotely from home) | A |
| 2 | Acceptable cities | B |
| 3 | Rest of their region or country | C |
| 4 | Everywhere else | C (or exclude) |

## Fit criteria (structure)

Themes and tasks that match their record; years of experience asked vs theirs; languages (fine / rule a job out); tools and technical skills (strong / weak); qualifications or licences the field requires; eligibility (work permits, nationality rules, security clearance); history (which kinds of applications got interviews, which never did).

## Hard exclusions (common starting list)

Go through it item by item; keep only what applies, and add their own.

- Levels they don't want (e.g. internships and traineeships, or very senior roles: Head of, Director, 10+ years)
- Contract types or hours they'd never take
- Roles requiring languages they don't speak
- Roles requiring qualifications, licences or permits they can't get
- Functions that sound close but aren't their work (write these for their field)
- Sub-fields, industries or employers they don't want
- Salary stated below their minimum (only if they set one)
- Postings from recruitment agencies that don't name the employer (optional)

## Job boards (structure)

The watchlist ends with job boards, marked "leads only". Suggest: LinkedIn (via alerts), one or two large general boards for their country, the boards specific to their field or profession, and public-sector portals if public employers are on their list. Use web search to find the right ones for their country and field.
