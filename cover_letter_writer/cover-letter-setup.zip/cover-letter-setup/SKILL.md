---
name: cover-letter-setup
description: "Sets up (or later changes) a personal cover-letter writer in Claude: a short interview on the user's CV, past cover letters, folders, format and rules, then builds a personal skill that writes cover letters from the full job posting, matched against their real record, in their own voice, checked by a simulated recruiter screen and an AI-writing check. Use whenever someone wants to set up, personalise or change a cover-letter writer, motivation-letter assistant or application-letter workflow, even if they don't name this skill."
---

# Cover letter setup

This kit sets up a cover-letter writer for one person (called **the user** below). At the end of setup they have a personal skill, `cover-letter-<name>`, that writes their cover letters with a fixed, careful method:

1. Secure the **full job posting** (saved as a file) before anything else.
2. Analyse the posting: requirements, tasks, ideal profile, screening keywords.
3. Classify the job and pick **reference letters** from the user's own past letters.
4. Build a **match matrix**: requirements against the user's real record, hard skills and provable results first.
5. **Ask the user** about anything uncertain instead of guessing.
6. Draft in the user's voice and format.
7. Check it with a simulated **recruiter screening tool**.
8. Check it with a simulated **AI-writing detector**.
9. Build the files and check the length.
10. Optionally log the application (tracker, Morning Job Run dashboard).
11. Report what to check before sending.

This kit does not write letters itself. It builds the skill that does, and later updates it ("update mode", below).

Files in this kit:

- `references/personal_skill_template.md`: the personal skill, with `{{PLACEHOLDERS}}` to fill.
- `references/placeholders.md`: every placeholder, where its value comes from, and the final checks.
- `references/integrations.md`: optional links to an application tracker and to a Morning Job Run dashboard.

---

## Ground rules

- **Their material, their rules.** Everything in the personal skill comes from the user's CV, their own past letters and their answers. Never carry over examples from this kit as facts about them.
- **One topic at a time.** Keep turns short. Use a multiple-choice tool for choices if the client has one (otherwise numbered options), and plain questions for open answers. Draft what you can yourself (from the CV and the letters) and ask the user to correct it, rather than asking open questions they have to think hard about.
- **Their language.** Run the interview in the language the user writes in. Write the skill in English unless they ask otherwise (Claude reads it), but keep any fixed phrases of their letters (greetings, sign-offs, date style) in the language they use.
- **Personal data stays in their skill.** Don't put their details anywhere else (no memory notes, no other artifacts). Remind them at the end that the generated skill contains personal information and must not be published.
- **No actions on their behalf.** The skill never submits applications, creates accounts or contacts anyone.
- **Shared accounts.** If someone else uses the same Claude account, name everything after the user and never read, change or reuse the other person's skills, files or letters.
- A skill can't save changes to itself from a chat. The output is always a new skill file the user installs (Save skill card, or upload in the skills settings).

---

## Setup mode (first time)

### 0. Welcome, checklist and environment

Tell them what will happen: 15–30 minutes of questions, then Claude builds their skill and they install it. They can stop and continue later; if they do, give them a short summary of their answers so far to paste into the next chat.

Show this checklist, then check what the session actually has and say plainly what's missing:

**Needed**
- [ ] **Their CV** (PDF or Word).
- [ ] **Some of their own past cover letters**: ideally 5 or more, recent ones first; if they saved the job postings next to them, even better. With none (e.g. a first job search), setup still works: the format and voice come from a few questions instead, and the skill improves as they add the letters they send.
- [ ] **Code execution and file creation** switched on (needed to read their files, build Word/PDF letters and package the skill).
- [ ] **Skills** enabled on their plan, so they can install the generated skill.

**Recommended**
- [ ] **File access to where they keep applications**: a connected folder (Claude desktop app) or, in Claude Code, the local folder. Without it, they upload letters and postings to each chat and download the results.
- [ ] **Subagents** available in the session (used for the two independent checks). Without them, the checks run in the same conversation, which is less strict.

**Optional**
- [ ] **Claude in Chrome**, to read job postings that block automated fetching.
- [ ] **An application tracker** (spreadsheet), to log each letter.
- [ ] **A Morning Job Run dashboard**, only if they also use the companion `job-search-setup` kit (published alongside this one), to write letters for the jobs they mark "Apply" there.

Then ask:

- **Their first name** (used in the skill name and file names) and full name (for letter headers). Make the slug: lowercase first name, accents removed and non-Latin names transliterated (agree it with them), letters and digits only, hyphens instead of spaces (e.g. "Anna-Lena" → `anna-lena`, "José" → `jose`). In shared-account mode, add the initial of the last name if another skill already uses the same first name. The skill name must be `cover-letter-<slug>`.
- **"Does anyone else use this Claude account?"** If yes, switch on shared-account mode (see ground rules).
- **Where they'll use it:** Claude desktop app with a connected folder / Claude Code with local files / web or mobile chat with uploads. Fill `{{FILE_ACCESS}}` accordingly (see `placeholders.md`). Without file access, a page-based length rule can only be checked if the session can export PDFs; suggest a word range instead (step 4).

### 1. Folders and files

Only if they have file access:

- **Applications folder** → `{{APPLICATIONS_FOLDER}}`: where their past applications live. List it, describe what you see (one folder per application? letters and postings side by side? file names?), and confirm.
- **Output folder** → `{{OUTPUT_FOLDER}}`: where new letters go. Default: a subfolder `Claude drafts – <Name>` inside the applications folder. Each letter gets its own subfolder `<Employer>_<Short_position>`.
- **File names** → `{{FILE_NAME_PATTERN}}`: draft it from their existing letters (e.g. `<First>_<Last>_Cover_Letter_<Employer>`), or default to `Cover_letter_<Name>_<Employer>`.

Without file access, set the folders to "uploads in the chat" and the delivery to "files offered for download".

### 2. Profile and fact bank

Ask for the CV. Read it, and read their past letters (step 3 reads them in detail; skim them now for facts). Draft the **fact bank** → `{{FACT_BANK}}`: the claims a letter may make without asking, in short sections:

- **Identity:** current role and employer, degree(s), field, how they describe themselves in their letters.
- **Experience:** one bullet per role: what they did, outputs, numbers, tools, who used the work.
- **Outputs and evidence:** projects, publications, products, portfolios, certifications, awards, anything checkable.
- **Skills:** tools, methods, technical skills, with their level where it matters.
- **Communication:** writing, presenting, teaching, public work.
- **Languages** with levels.

Facts found only in their letters (not the CV) are shown to them one by one before they go in: letters are sometimes tailored or out of date. Confirmed ones go in marked "(from their letters)". Where CV and letters disagree (numbers, dates, titles), ask which is right.

Show the draft, then ask only for gaps:

- **What they'd never claim** → `{{NEVER_CLAIM}}`: skills, tools, languages, levels or experiences they don't have but that come up in postings in their field. Suggest the usual suspects for their field and let them tick.
- **Availability** (start date, notice period), **location lines** they're happy to use (e.g. "looking to move to <city>"; "currently based in <city>") and **references** they name in letters, if their letters do → `{{CLOSING_FACTS}}`.
- **Anything recent** not yet on the CV.

### 3. Past letters: voice, format and categories

Read every past letter they have (Word, PDF, Google Docs exports, plain text). Exclude any letter they say wasn't written by them, other people's letters, unfinished drafts and templates. Then:

1. **Catalogue** each letter: employer, role, date (from the letter's date line, else file date), language, length (words), and path → part of `{{LETTER_CATALOGUE}}`.
2. **Format** → `{{LETTER_FORMAT}}`: header block, recipient block, date style, subject line pattern, greeting, closing, signature, paragraph count, typical length in words and pages, file type. Describe it; never paste a letter's text into the skill.
3. **Formatting template** → `{{FORMAT_TEMPLATE}}`: the letter file whose layout new letters will copy (usually the most recent Word letter). If they only have PDFs, note "no Word template: build from scratch with the format described".
4. **Voice notes** → `{{VOICE_NOTES}}`: 4–8 observations on how they write (sentence length, how they open, how personal they get, register, spelling variety such as British or American English, recurring structures). Also list their **stock phrases** (phrases they reuse that read as generic) → `{{STOCK_PHRASES}}`: the skill will avoid them even though they are theirs.
5. **Categories** → `{{CATEGORIES}}`: propose 2–6 categories of job that need different letters in *their* field, based on what their letters actually do differently. Each category gets: a name, a one-line rule for deciding it from a posting, and what letters in that category lead with. Typical axes (pick what fits, don't force them): sector or type of employer; how specialised or senior the role is; research/creative/technical depth vs client- or operations-facing; language or country. Show the proposal, adjust with them, then assign every catalogued letter to a category in `{{LETTER_CATALOGUE}}` (a table: category · employer and role · date · path).

If they have fewer than 3 letters in total, use one category and say that the skill will get better as they add letters (update mode).

**If they have no past letters at all:** skip the catalogue (it says "No letters yet"), and ask instead: the format they want (or offer a standard business-letter format for their country), 3–4 questions on tone (formal or plain, how personal, how much about motivation vs evidence), and whether they have any other writing of theirs (a personal statement, a LinkedIn summary) to take the voice from. Use one category.

### 4. Rules and preferences

Ask with options where possible:

- **Language** → `{{LANGUAGE_RULE}}`: always one language / match the posting's language / ask each time.
- **Length** → `{{LENGTH_RULE}}` and `{{LENGTH_CHECK}}`: e.g. "at most one page", "1 to 1.5 pages", "300–400 words". Suggest the range their own letters fall in. Page rules need a PDF export to check; where that isn't available, use a word range (give the equivalent of their usual page length).
- **Output** → `{{OUTPUT_FORMATS}}`: Word + PDF (default), Word only, or plain text to paste into application forms.
- **Questions** → keep the default: always ask before drafting when a match is uncertain. Confirm they're happy with one batched round of questions per batch of letters.
- **Gaps** → `{{GAP_RULE}}`: when a posting requires something they don't have, should the letter say so in one plain sentence, or leave it out and only flag it to them?
- **Checks** → keep both checks on (default). Pass thresholds default: screening recommendation "advance", score ≥ 80 and every must-have scored at least 1; detector verdict "likely human", no high-severity flags and at most two low ones. Let them relax these only if they ask → `{{SCREEN_PASS}}`, `{{DETECTOR_PASS}}`.
- **Anything they always or never want in a letter** (e.g. "never mention salary", "always mention my portfolio link") → `{{HOUSE_RULES}}`.

### 5. Optional integrations

Ask whether they use an application tracker or a Morning Job Run dashboard. If yes, follow `references/integrations.md`. If no, fill those placeholders as that file explains.

### 6. Confirm

Show a compact summary: name and slug; environment and folders; fact bank headline (roles, top outputs) and the never-claim list; format and length; categories with letter counts; language rule; checks; integrations. Build only after they say it's right.

### 7. Build the personal skill

1. Copy `references/personal_skill_template.md` to `cover-letter-<slug>/SKILL.md` in a temporary working folder (e.g. under `/tmp` on macOS or Linux) and fill every placeholder, using `references/placeholders.md` as the checklist.
2. Check: `grep -n "{{" SKILL.md` returns nothing; `name` is exactly `cover-letter-<slug>`; the description is under about 1,000 characters.
3. Package it the way this environment installs skills:
   - if a skill-proposal tool is available (e.g. a "propose skills" card), propose it as a new skill;
   - otherwise, if a packaging script exists (e.g. the skill-creator's `package_skill.py`), use it;
   - otherwise zip the folder (`cover-letter-<slug>/SKILL.md` inside) and give them the file.
4. Tell them how to install it (Save skill on the card, or upload the file in the skills settings) and to check the installed name is `cover-letter-<slug>`.
5. Remind them the skill contains their CV details and letter catalogue: keep it private; never commit it to a public repository. Delete the temporary working copy and any zip once it is installed.

### 8. First letter

Suggest they try it on one real posting in a **new chat**: "Write a cover letter for <link or file>". Tell them what to expect: it will save the posting first, may ask a few questions about their experience, and will report the two check results with the letter.

---

## Update mode (any time later)

When they want to change something (new CV, new letters to add as references, new facts, a corrected claim, a different length or language rule, categories, folders, integrations):

1. Get their current skill: ask them to upload the skill file, or, if the environment exposes installed skills, look for `cover-letter-*` there. If several exist, ask which is theirs; in shared-account mode, never open the others.
2. Copy it into a temporary working folder and change only what they asked. Typical updates:
   - **Add facts** they gave while writing a letter: this chat can't see that conversation, so ask them to paste the facts (the personal skill lists them in its report); add them to the fact bank, marked with the date.
   - **Add letters** they have since sent: catalogue them, assign a category, update voice notes if their style has moved.
   - **Correct the never-claim list.**
3. Show a short before/after, then package and present as in step 7. They install it and confirm replacing the old version.
