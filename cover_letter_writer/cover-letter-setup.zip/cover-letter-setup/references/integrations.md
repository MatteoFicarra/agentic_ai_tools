# Optional integrations

Two optional links. Both need file access or the relevant tool in the user's environment. Fill the placeholders below according to what the user switched on. Text inside the code blocks goes into the personal skill as written, with `{{…}}` placeholders filled.

---

## Where jobs come from — `{{JOB_SOURCES}}`

**Always include:**

```
{{OWNER_NAME}} names the job: a link, a posting file, or pasted text. Several jobs at once are fine. With file access, skip any job that already has a letter in the output folder unless {{OWNER_NAME}} asks for a rewrite (then save it as the next `_vN`); list skipped jobs in the report.
```

**If they use a Morning Job Run dashboard** (built by the companion `job-search-setup` kit published alongside this one; skip this for anyone else), append:

```
"The Apply jobs" means the jobs marked Apply on the dashboard at <dashboard URL>: read its `jobs` collection with the Artifact tool's database actions (a query where `status` is "apply"). The dashboard card is only used to find the job and its URL; the posting itself is still secured in step 1. Never change a job's `status` or `my_note`.
```

**`{{INTEGRATION_DESC}}`:** `, and logs them in their tracker` and/or `, including for jobs marked Apply on their Morning Job Run dashboard`, or an empty string.

---

## Logging — `{{LOG_STEP}}` and `{{TRACKER_RULE}}`

### No tracker, no dashboard

`{{LOG_STEP}}`:

```
Nothing to log in this setup. List the files and their location in the report.
```

`{{TRACKER_RULE}}`: empty string.

### Tracker (spreadsheet)

The procedure below is for an Excel file (`.xlsx`). For a **CSV** tracker, append a row with Python's `csv` module (back up first; never rewrite existing rows). For a **Google Sheet**, edit it only through a connected Google Sheets tool if the session has one; otherwise put the row in the report for them to paste.

During setup, open their tracker with them and record: file path, sheet, header row, first data row, the columns in order, which columns hold formulas, which have drop-down lists (and their values), how a new row is started (empty rows pre-filled with formulas, or appended at the end), the column that records "cover letter written" if any, and the style of their notes. If they have no tracker but want one, offer to create a simple spreadsheet (employer, role, city, link, deadline, status, date applied, cover letter, notes) and describe it the same way.

`{{TRACKER_RULE}}`:

```
7. **Tracker:** back up before every edit (`<tracker name>_backup_YYYY-MM-DD.xlsx` in a `backups` subfolder of the output folder, keeping an existing backup of the same day). Only add new rows. The one change allowed to an existing row is marking the cover-letter column as done for a job whose letter you just wrote.
```

`{{LOG_STEP}}`:

```
**Tracker:** `<file>`, sheet `<sheet>`. Header row <n>; data from row <n>.

Columns: <in order>. Formula columns: <list>. Drop-down columns and values: <list>. Cover-letter column: <name, and the value meaning "done">.

1. Back up the tracker (rule 7).
2. Load it with openpyxl without `data_only`, so formulas survive. Before saving, compare the number of drop-down lists openpyxl sees (`len(ws.data_validations.dataValidation)`) with the number in the file itself (count `<dataValidation ` and `<x14:dataValidation ` in the sheet's XML inside the .xlsx). openpyxl drops some kinds of drop-down lists when it saves. If the counts differ, don't save: tell {{OWNER_NAME}}, and offer to recreate those lists as standard drop-downs (same ranges and value lists) in the saved file.
3. **If the job has no row:** <how a new row is started in this tracker>. Fill: <column → value mapping, e.g. employer, role, city, link, deadline as a date, status "<their 'not started' value>", cover letter "<done value>">. Notes in their style: <describe>.
4. **If the row exists:** only mark the cover-letter column as done.
5. Save, re-open, and check the row and the drop-down count.
```

If they also use the dashboard, add to `{{LOG_STEP}}`:

```
**Dashboard:** after the tracker, set the job's `in_tracker` field to "#<row ID> · <status>" with one batched database update, pinned to the version you read. Touch no other field.
```

### Dashboard only (no tracker)

`{{LOG_STEP}}`:

```
Nothing to log beyond the files: the dashboard's Apply tab already shows these jobs. Don't change any dashboard field.
```

`{{TRACKER_RULE}}`: empty string.
