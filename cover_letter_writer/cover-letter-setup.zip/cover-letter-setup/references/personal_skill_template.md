---
name: "cover-letter-{{OWNER_SLUG}}"
description: "{{OWNER_NAME}}'s personal cover-letter writer{{SHARED_DESC}}. Writes {{OWNER_NAME}}'s cover and motivation letters from the full job posting, matched against their real record and written in their own voice, then checks each letter with a simulated recruiter screen and an AI-writing detector{{INTEGRATION_DESC}}. Use for any cover letter, motivation letter or application letter {{OWNER_NAME}} asks for."
---

# Cover letter writer – {{OWNER_NAME}}

This skill writes every cover letter for {{OWNER_FULL_NAME}}. Any request for a letter ("cover letter for <job>", "write the letters for these postings", "redo the letter for <employer>") runs through this skill from step 1, never as an ad-hoc letter.

The workflow has a fixed order. Do not skip or reorder steps:

1. Set up the folder and secure the **full job posting** (gate).
2. Analyse the posting.
3. Classify the job and choose **reference letters**.
4. Build the **match matrix**.
5. **Ask {{OWNER_NAME}}** everything you are unsure about (one batched round).
6. Draft.
7. **Screening check** (impersonate the employer's screening tool).
8. **AI-detection check** (impersonate the employer's AI-writing detector).
9. Build the files and check the length.
10. Log the application.
11. Report.

With several jobs, run steps 1–4 for all of them, ask one combined round of questions (step 5), then run steps 6–11 for all of them, and report once.

To change the settings (facts, letters, format, rules), {{OWNER_NAME}} uses the setup skill `cover-letter-setup` in update mode; this file is regenerated from it.

---

## Rules (always apply)

1. **Ownership.** This skill and everything it creates belong to {{OWNER_NAME}}. Name new files after {{OWNER_NAME}} (pattern below).
{{SHARED_ACCOUNT_RULE}}
2. **Files:** never edit, move or delete {{OWNER_NAME}}'s existing files. Everything new goes in the output folder ({{OUTPUT_FOLDER}}), one subfolder per letter. Never overwrite a letter: a rewrite is saved as `_v2`, `_v3`.
3. **No actions on {{OWNER_NAME}}'s behalf:** never submit an application, create an account, or contact anyone.
4. **Honesty:** a letter may only claim what is in the fact bank below, {{OWNER_NAME}}'s CV, their own past letters, or their answers in the current conversation. **When unsure how an experience matches a requirement, or what an experience involved, ask; never guess.** Neither check (steps 7–8) may add a claim that isn't backed this way.
5. **Language:** {{LANGUAGE_RULE}}
6. **Source of truth for the job:** the full posting, never a summary of it (not a job-board snippet, not a dashboard card, not search-result text).
{{TRACKER_RULE}}

If a step would break a rule, stop and ask.

---

## Where things are

- **File access in this setup:** {{FILE_ACCESS}}
- **Past applications:** {{APPLICATIONS_FOLDER}}
- **Output folder:** {{OUTPUT_FOLDER}}. With file access, one subfolder per letter: `<Employer>_<Short_position>` (underscores; no accents, apostrophes or spaces).
- **File names:** `{{FILE_NAME_PATTERN}}`, with the extensions of the output formats in step 9; a rewrite adds `_v2`, `_v3`.
- **Formatting template:** {{FORMAT_TEMPLATE}}. Used **only for the layout**; the content comes from the reference letters chosen in step 3. Never edit it; copy it.
- **CV:** {{CV_FILE}}

---

## Step 1: folder and job posting (gate)

1. **Identify the jobs.** {{JOB_SOURCES}}
2. **Create the letter's subfolder** in the output folder (with file access; otherwise keep everything for this job together in the conversation).
3. **Secure the full posting as a file in that subfolder** (`Job_Posting_<Employer>.pdf`, or `.txt` if no PDF converter is available):
   - **{{OWNER_NAME}} gave a file or pasted the full text:** use it (save pasted text as the posting file).
   - **A link:** if Claude in Chrome is connected, open the page (read only: never click Apply, sign in or accept anything beyond declining non-essential cookies) and take the complete page text. Save it with the page title, URL and capture date at the top.
   - **No browser:** a web fetch may be used only if it returns the full text, not a summary. Ask for "the complete posting text, verbatim, every section" and compare its length and sections with what the page should contain. If anything looks summarised or cut, treat the posting as unreachable.
   - **Unreachable** (closed, login wall, blocked, summary only): ask {{OWNER_NAME}} to save the posting in the subfolder (in a browser: print → Save as PDF), upload it, or paste it. **Stop work on that job until the posting is there.** Other jobs in the batch carry on.
4. **Read the posting** from the file. Everything in step 2 comes from this text.

---

## Step 2: analyse the posting

Write out, for yourself:

- **What the job is:** team, what it produces, for whom, and how the work is used. Note the reference number, contract, location and any application instructions (e.g. "a short covering letter", questions the letter must answer).
- **Requirements**, split into *required* and *preferred*, in the posting's exact wording.
- **Tasks**, in order of how much of the job they seem to be.
- **Ideal profile:** in two or three sentences, the person the hiring manager is picturing (background, seniority, the one or two things that would make them say yes).
- **Screening keywords:** the specific terms a recruiter or screening tool would look for (skills, tools, methods, domains, job-title words).
- **Employer facts:** one or two concrete, true points about the team or employer, from the posting or, if the session has web access, the employer's own site. Without web access, use what the posting says. Never rely on memory you aren't sure of.

---

## Step 3: classify the job and choose reference letters

**Classify the job yourself**, from the posting, into one of {{OWNER_NAME}}'s categories. Don't ask; state the category and a one-line reason in the report. When a job sits between two categories, go by what the task list spends most of its space on, not by the job title.

{{CATEGORIES}}

**Choosing references.** Read **three to four** of {{OWNER_NAME}}'s own letters, never just one:

- the **two most recent** letters in the same category;
- one or two more from the same category, closest in role or employer type;
- if the category has fewer than three letters, fill up from the closest other category.

Give more weight to recent letters: they carry {{OWNER_NAME}}'s current situation and latest phrasing. Older letters are for structure, register and arguments that worked; facts in them must be checked against the fact bank, since they may describe an earlier situation.

**Never use as references:** anything in the output folder (letters drafted with Claude would make new letters converge on AI phrasing), other people's letters, templates, or unfinished drafts.

**Catalogue of {{OWNER_NAME}}'s letters** (at the last update). With file access, look before each run for letters added since (by date) in the applications folder and use them too; without it, ask whether there are recent letters to upload. Suggest an update of this skill if there are several new ones.

If the catalogue has no letters, skip the references: follow the format and voice notes below, and say in the report that the letter had no reference letters.

{{LETTER_CATALOGUE}}

If a posting was saved next to a past letter, compare them: it shows which requirements {{OWNER_NAME}} chose to answer and how.

---

## Step 4: match matrix

Build a table with one row per requirement or main task:

| Requirement (posting's words) | Required / preferred | Type | Evidence from {{OWNER_NAME}}'s record | Strength | Use in letter |
|---|---|---|---|---|---|

**Type**, in priority order:

1. **Hard skills and methods** (techniques, tools, domain knowledge, qualifications).
2. **Directly relevant experience** (roles, organisations, tasks actually done).
3. **Provable outcomes** (outputs, results with numbers, products, publications, portfolios, awards).
4. **Soft skills** (communication, teamwork, leadership): only with a concrete proof from the fact bank.
5. **Baseline requirements** (a language every applicant has, standard office software, the minimum degree, "motivated", "team player"): **leave these out.** Something every applicant has does not belong in the letter.

The letter is built from types 1–3. A type 4 requirement earns a sentence only with evidence. A language is mentioned only when the posting requires it and it isn't a given for the role, in one short clause.

**Strength:** *direct* (done exactly this), *transferable* (a clear bridge exists and can be stated in one sentence), *gap* (doesn't have it), or *unsure*.

**Unsure** covers both cases where you can't tell:

- whether an experience meets a requirement;
- what an experience actually involved (scope, tools, who used the result, numbers).

Every *unsure* row becomes a question in step 5. Never fill it with a plausible guess.

---

## Step 5: ask {{OWNER_NAME}} (one batched round)

If the matrices have *unsure* rows or postings are missing, send one message (or one multiple-choice question set) covering every job in the batch, before drafting anything:

- **Unsure matches:** each as a specific question tied to the requirement, e.g. "The posting asks for <requirement>. Did your work at <organisation> involve this? If yes, what exactly?"
- **Missing postings:** which subfolders are waiting for one.

Then wait for the answers. Use them as facts for this letter. At the end of the run, offer to add new, reusable facts to the fact bank (an update through `cover-letter-setup`). If nothing is unsure and no posting is missing, go straight to step 6.

If {{OWNER_NAME}} is clearly away (a scheduled or unattended run), don't draft letters that depend on open questions; report the questions instead.

---

## Step 6: draft

**Format** (from {{OWNER_NAME}}'s own letters):

{{LETTER_FORMAT}}

- Fill the recipient and any subject line the way their format does, with details from the posting only. Never invent a name, address or reference number; if the format expects one the posting doesn't give, leave it out and flag it.

**Body:** follow the structure of the reference letters for this category. Without a stronger pattern in them, use:

1. **Who they are and the role:** current position, the exact role applied for, and a one-line identity matched to the job's core.
2. **Why this job:** what the team does and how its work is used, and why that is the work {{OWNER_NAME}} wants. Concrete and true; no flattery.
3. **Strongest matches first:** the top rows of the matrix, each with its evidence.
4. **Next matches:** the remaining strong rows, tied to the posting's tasks.
5. **Skills and gaps:** tools and communication only as far as the posting values them, with proof. A required item they lack: {{GAP_RULE}}
6. **Close:** availability and relevant practical facts, from:
{{CLOSING_FACTS}}

**Voice** ({{OWNER_NAME}}'s own writing, from their letters):

{{VOICE_NOTES}}

**Writing rules:**

- Use the posting's own words for the skills it asks for, inside natural sentences; never as a keyword list.
- Every paragraph carries at least one concrete fact (a number, a named output, an organisation).
- Keep {{OWNER_NAME}}'s idiom; don't polish it into consultant prose.
- Never mention other applications, salary expectations or any internal scoring.
{{HOUSE_RULES}}

**Length:** {{LENGTH_RULE}} Checked in step 9.

---

## Step 7: screening check (impersonate the employer's screening tool)

Run this as a **fresh subagent**, so it judges the letter cold, without your reasoning. Give it only the full posting text and the letter text. If no subagent is available, do it yourself, strictly in role, after re-reading only those two texts.

Prompt:

> You are the AI screening tool used by <Employer>'s recruiting team to shortlist applicants for "<Title>". You will receive the job posting and a candidate's cover letter.
> 1. From the posting alone, list the screening criteria you would use, each marked must-have / strong plus / nice-to-have, with the exact keywords and phrases you would search for.
> 2. Score the letter on each criterion: 0 = absent, 1 = implied or asserted without evidence, 2 = explicit with concrete evidence.
> 3. Give a weighted score out of 100 and a recommendation: advance / borderline / reject.
> 4. List the missing or weak criteria and the absent keywords, most important first.
> Be strict, as a real screening tool would be. Do not suggest wording.

**Pass:** {{SCREEN_PASS}}

**If it fails:** revise to close each gap, but only with true evidence (rule 4). The screener's list of absent keywords is a list of things to check, not things to add: a keyword goes in only if the fact bank backs it. A must-have {{OWNER_NAME}} can't evidence stays a gap: handle it as in step 6 and list it in the report. Never stuff keywords. Rerun, at most three rounds, and keep the scores for the report. A letter can end below the bar because of real gaps; that is better than a letter that passes on claims {{OWNER_NAME}} can't back.

---

## Step 8: AI-detection check (impersonate the employer's AI-writing detector)

Again a **fresh subagent**, given only the letter. If no subagent is available, do it yourself, strictly in role, after re-reading only the letter.

Prompt:

> You are the tool <Employer>'s HR team uses to flag cover letters that were written or heavily polished by AI. Read the letter and report to HR:
> 1. Every passage you would flag, quoted, with the tell it shows and a severity (high / medium / low).
> 2. An overall judgement: likely human / mixed / likely AI, with one line of reasoning.
> Look at word choice, sentence rhythm, structure, how specific the content is, and how the letter reads as a whole. Be strict.

**Pass:** {{DETECTOR_PASS}}

**If it fails:** rewrite only the flagged passages, in {{OWNER_NAME}}'s voice as it appears in the reference letters, then rerun (at most three rounds). Then rerun step 7 once, so the rewrite hasn't lost a match. If that rerun scores lower than before, restore the lost evidence in plain wording and stop there: report both results as they are rather than looping.

When rewriting, look out for the usual tells, beyond what the detector flags:

- **Vocabulary:** delve, tapestry, landscape, navigate, leverage, pivotal, robust, seamless, cutting-edge, multifaceted, testament, resonate, "aligns perfectly", "unique blend", "passionate", "thrilled", "I am confident that".
- **Patterns:** em-dashes; "not only… but also"; "not X, but Y"; groups of three everywhere; paragraphs ending in a tidy summary sentence; paragraphs of identical length and shape; sentences of uniform length; generic praise of the employer; the posting's phrases echoed verbatim and in its own order; a sentence that restates the job ad back to the reader; a gap admitted and immediately spun into a strength.
- **Content:** claims without a number, name or output behind them; hedging; the same idea said twice.
- **{{OWNER_NAME}}'s own stock phrases**, which also read as generic: {{STOCK_PHRASES}}

Take structure and register from the reference letters, not their stock phrases. Never game the detector: no deliberate typos, odd characters, invisible text or broken grammar. The aim is a letter that reads like {{OWNER_NAME}} wrote it.

---

## Step 9: build the files and check the length

Output: {{OUTPUT_FORMATS}}

**Plain-text output:** skip the Word and PDF steps. Give the letter in the chat (and save it as `.txt` in the letter's subfolder with file access), and check the length in words.

**Word file from the formatting template.** If the template is "none" or the map is empty, skip this code and build a clean document with the format in step 6. Otherwise run Python with python-docx (install it if missing). The template map says which paragraphs of the template hold which part of the letter; parts not listed are kept as they are (e.g. the sender header and signature).

```python
import docx, copy, os
from docx.text.paragraph import Paragraph
TEMPLATE = r"{{FORMAT_TEMPLATE_PATH}}"
MAP = {{TEMPLATE_MAP}}   # paragraph indices in the template

def settext(p, text):            # keeps the first run's formatting; "\n" becomes a line break
    if not p.runs:
        p.add_run("")
    for r in p.runs[1:]:
        r._element.getparent().remove(r._element)
    p.runs[0].text = text

def build(out_path, parts, body):
    """parts: dict of part name -> text for the single-paragraph parts in MAP
       (e.g. recipient, date, subject, greeting); body: list of paragraph texts."""
    assert not os.path.exists(out_path), "exists - save as the next _vN"
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    d = docx.Document(TEMPLATE)
    ps = list(d.paragraphs)
    for name, idx in MAP.items():
        if name != "body" and name in parts:
            settext(ps[idx], parts[name])
    body_ps = [ps[i] for i in MAP["body"]]
    model = body_ps[0]
    for p in body_ps[1:]:
        p._element.getparent().remove(p._element)
    anchor = model
    for text in body[1:]:
        new = copy.deepcopy(model._element)
        anchor._element.addnext(new)
        anchor = Paragraph(new, model._parent)
        settext(anchor, text)
    settext(model, body[0])
    d.save(out_path)
```

**PDF:** convert with LibreOffice if available (`soffice --headless --convert-to pdf --outdir <folder> <file>.docx`). If no converter exists in this environment, deliver the Word file and say the PDF must be exported by hand.

**Length check:** the target is {{LENGTH_RULE}}
{{LENGTH_CHECK}}

Fix the length by adding or cutting content (cut the weakest matrix row first), never by changing font, spacing or margins. A file built in this run may be rebuilt in place until it is reported; after that, only new versions. Look at one finished PDF per batch (render a page image if you can) to check the layout: header, recipient, nothing orphaned on the last page.

---

## Step 10: log the application

{{LOG_STEP}}

---

## Step 11: report

Keep it short:

- **One table:** job, category (with the one-line reason), references used, final screening score and recommendation, detector verdict, where the files are.
- **Check before sending:** gaps against required items, claims that rest on {{OWNER_NAME}}'s answers in this conversation, missing reference numbers, anything unconfirmed about the posting (e.g. text taken from a job board rather than the employer's page).
- **Waiting:** jobs held for a posting, or for answers.
- **New facts:** offer to add the reusable facts {{OWNER_NAME}} gave in this run to the fact bank (an update through `cover-letter-setup`).

Don't paste the letters into the chat unless asked, unless the output format is plain text.

---

## Fact bank

Claims a letter may make without asking. The CV and {{OWNER_NAME}}'s own past letters are also valid sources; when they disagree, use the most recent and flag it.

{{FACT_BANK}}

**Never claim** (unless {{OWNER_NAME}} confirms otherwise in step 5):

{{NEVER_CLAIM}}
