# Placeholder map

Every placeholder in `personal_skill_template.md`, where its value comes from, and what to use when it doesn't apply. After filling, `grep -n "{{" SKILL.md` must return nothing.

| Placeholder | Source (setup step) | If not applicable |
|---|---|---|
| `{{OWNER_NAME}}` | First name (0) | — |
| `{{OWNER_SLUG}}` | Slug of the first name (0) | — |
| `{{OWNER_FULL_NAME}}` | Full name (0) | — |
| `{{SHARED_DESC}}` | Shared-account mode (0): ` (belongs to <Name> only)` | empty string |
| `{{SHARED_ACCOUNT_RULE}}` | Shared-account mode (0), text below | empty string |
| `{{FILE_ACCESS}}` | Environment (0), text below | — |
| `{{APPLICATIONS_FOLDER}}` | Step 1: the path in backticks | `uploaded in the chat when needed` |
| `{{OUTPUT_FOLDER}}` | Step 1: the path in backticks | `none: files are offered for download in the chat` |
| `{{FILE_NAME_PATTERN}}` | Step 1 | `Cover_letter_<Name>_<Employer>` |
| `{{CV_FILE}}` | Step 2: the path in backticks | `uploaded in the chat when needed` |
| `{{FACT_BANK}}` | Step 2 | — |
| `{{NEVER_CLAIM}}` | Step 2, as a bullet list | `- Nothing listed yet: ask whenever a posting requires something not in the fact bank.` |
| `{{CLOSING_FACTS}}` | Step 2: availability, location lines, references, as indented bullets | `   - availability: ask {{OWNER_NAME}}` |
| `{{LETTER_CATALOGUE}}` | Step 3: table category · employer and role · date · path | `No letters yet.` |
| `{{LETTER_FORMAT}}` | Step 3: bullet list (header, recipient, date style, subject line, greeting, closing, signature, paragraphs, length) | the format agreed in step 3 (no-letters path) |
| `{{FORMAT_TEMPLATE}}` | Step 3: path of the template letter, in backticks | `none` |
| `{{FORMAT_TEMPLATE_PATH}}` | The same path, plain (no backticks), for the Python code | `none` |
| `{{TEMPLATE_MAP}}` | Step 3, procedure below | `{}` (step 9 then builds a clean document) |
| `{{VOICE_NOTES}}` | Step 3: bullet list | the tone answers from step 3 (no-letters path) |
| `{{STOCK_PHRASES}}` | Step 3: quoted phrases separated by semicolons | `none noted yet.` |
| `{{CATEGORIES}}` | Step 3: one bullet per category: **name**: rule for deciding · what letters in it lead with | one category: `- **All jobs**: every job uses the same references.` |
| `{{LANGUAGE_RULE}}` | Step 4, as a full sentence | — |
| `{{LENGTH_RULE}}` | Step 4, as a full sentence (e.g. "between 1 and 1.5 pages in the template layout.") | — |
| `{{LENGTH_CHECK}}` | Step 4, variant below | — |
| `{{OUTPUT_FORMATS}}` | Step 4 | `a Word file and a PDF.` |
| `{{HOUSE_RULES}}` | Step 4, as bullets starting with `- ` | empty string |
| `{{GAP_RULE}}` | Step 4: `one plain sentence that names it, without apology or spin.` or `leave it out of the letter and flag it in the report.` | the first |
| `{{SCREEN_PASS}}` | Step 4 (default below) | — |
| `{{DETECTOR_PASS}}` | Step 4 (default below) | — |
| `{{JOB_SOURCES}}`, `{{INTEGRATION_DESC}}`, `{{LOG_STEP}}`, `{{TRACKER_RULE}}` | Step 5, per `integrations.md` | per `integrations.md` |

`{{TRACKER_RULE}}` and the tracker version of `{{LOG_STEP}}` always go in together (the log step refers to rule 7).

Replace `{{OWNER_NAME}}` inside any text you paste in from this file or from `integrations.md`.

---

## `{{SHARED_ACCOUNT_RULE}}` (shared-account mode only)

Indented as sub-bullets of rule 1:

```
   - This Claude account is shared. Never read, change or use other people's skills, files or letters.
```

## `{{FILE_ACCESS}}` by environment

- **Claude desktop app with a connected folder:** `The applications folder is connected to the session. Work on files there directly with the tools that reach it; copy a file into the sandbox only to look at a page image or use a tool that isn't available next to the files.`
- **Claude Code:** `Files are on the local filesystem; use the paths below directly.`
- **Web or mobile chat:** `No folder access. Ask {{OWNER_NAME}} to upload the posting and, when needed, the CV and the reference letters named in step 3; deliver the finished files for download.`

## `{{TEMPLATE_MAP}}`: how to build it

Open the template letter with python-docx and print every paragraph with its index, alignment and the first 60 characters. Identify, with the user if unclear:

- the single paragraphs that change for every letter: e.g. `recipient`, `date`, `subject`, `greeting` (only those the format has);
- `body`: the list of indices of the body paragraphs (consecutive);
- everything else (sender header, closing, signature) stays as it is and is not listed.

Write it as a Python dict, e.g. `{"recipient": 2, "date": 3, "subject": 4, "greeting": 5, "body": [6, 7, 8, 9, 10, 11]}`. Then **test it**: build one letter in a temporary working folder with dummy text (`build("<temp folder>/test.docx", {...}, ["Paragraph one.", "Paragraph two.", "Paragraph three."])`), reopen it and check that the parts landed in the right places, the header and signature are intact and the formatting is preserved. Fix the map until it is right. If the template can't be mapped cleanly (text boxes, tables, multiple sections), set the map to `{}` and the template to "none".

## `{{LENGTH_CHECK}}` variants

**Length in pages** (needs a PDF converter):

````
After exporting the PDF, measure how many pages it fills, including the last partial page. The result must fall between <min> and <max>:

```python
import re, subprocess, sys, docx
pdf, docx_path = sys.argv[1], sys.argv[2]
sec = docx.Document(docx_path).sections[0]
top, bottom = sec.top_margin.pt, sec.bottom_margin.pt
html = subprocess.run(["pdftotext", "-bbox", pdf, "-"], capture_output=True, text=True).stdout
pages = html.split("<page ")[1:]
h = float(re.search(r'height="([\d.]+)"', pages[-1]).group(1))
ymax = max(float(y) for y in re.findall(r'yMax="([\d.]+)"', pages[-1]))
print(round(len(pages) - 1 + (ymax - top) / (h - top - bottom), 2))
```

If `pdftotext` isn't available, count the PDF's pages and look at the last page instead. If no PDF can be exported in this session, check the body word count against <words min>–<words max>, the word range that corresponds to the page rule in {{OWNER_NAME}}'s letters.
````

**Length in words:**

```
Count the words of the body paragraphs (not header, recipient or signature). The count must fall between <min> and <max>.
```

Fill `<min>` and `<max>` (and, for pages, the word-range fallback) from the user's length rule and their past letters.

## Check defaults

- `{{SCREEN_PASS}}`: `recommendation "advance", score of at least 80, and every must-have scored at least 1 (2 wherever {{OWNER_NAME}} has evidence).`
- `{{DETECTOR_PASS}}`: `verdict "likely human", no high-severity flags, at most two low ones.`

---

## Final checks before packaging

- No `{{` left anywhere.
- `name` is `cover-letter-<slug>`, lowercase, hyphens only; the description is under about 1,000 characters.
- No text from the user's letters is pasted into the skill beyond short quoted stock phrases; the format and voice are described, not copied.
- The template map was tested (or set to `{}`).
- Every letter in the catalogue has a category, and every category has at least one letter (or is marked "no letters yet: use the closest category").
- The never-claim list and the fact bank don't contradict each other.
- Paths in the skill exist (when there is file access).
